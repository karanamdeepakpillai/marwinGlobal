<?php
    
$username = $_POST['username'];
$password = $_POST['password'];

if (!empty($username) || !empty($password)) {
    include 'dbConnect.php';
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
        echo '{"head":{"status":"Failure","err_msg":"Internal server occured, please try after sometime."},"body":{}}';
        die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
        $SELECT = "SELECT * FROM USER_DATA WHERE USERNAME = ? AND PASSWORD = ?";
        $stmt = $conn->prepare($SELECT);
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $stmt->store_result();
        $rnum = $stmt->num_rows;
        if($rnum==1){
            $SELECT = "SELECT * FROM contact_dtls order by record_created_dt desc";
            $stmt = $conn->prepare($SELECT);
            $stmt->execute();
            $res = $stmt->get_result(); 
            $rows = $res->fetch_all(MYSQLI_ASSOC);
            echo '{"head":{"status":"Success","err_msg":""},"body":'.json_encode($rows).'}';
        }else{
            echo '{"head":{"status":"Failure","err_msg":"Username/Password do not match."},"body":{}}';
        }
        $stmt->close();
        $conn->close();
    }
} else {
    echo '{"head":{"status":"Failure","err_msg":"All fields are mandatory."},"body":{}}';
    die();
}

?>
