<?php
session_start();
function getIPAddress() {
    //whether ip is from the share internet
    if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    //whether ip is from the proxy
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    //whether ip is from the remote address
    else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
$ip = getIPAddress();
include 'dbConnect.php';
//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
$SELECT = "SELECT * FROM Session_Count";
$stmt = $conn->prepare($SELECT);
$stmt->execute();
$stmt->store_result();
$rnum = $stmt->num_rows;
$countInc = 5000;
if(isset($_SESSION['session_created'])){
    echo $rnum + $countInc;
}else{
    
    $_SESSION['session_created'] = true;
    
    $INSERT = 'INSERT INTO Session_Count (Session_Count_RK, IPAddress) VALUES (?, ?)';
    //Prepare statement
    $stmt = $conn->prepare($INSERT);
    $stmt->bind_param("is",$rnum,$ip);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    echo $rnum + 1 +$countInc;
}



?>