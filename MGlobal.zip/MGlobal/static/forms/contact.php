<?php
    
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

if (!empty($name) || !empty($email) || !empty($subject) || !empty($message)) {
    include 'dbConnect.php';
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
        $SELECT = "SELECT * FROM contact_dtls";
        $stmt = $conn->prepare($SELECT);
        $stmt->execute();
        $stmt->store_result();
        $rnum = $stmt->num_rows;
        $INSERT = "INSERT Into contact_dtls (contact_dtls_rk, first_name, email_id, subject, message) values(?, ?, ?, ?, ?)";
        //Prepare statement
            $stmt = $conn->prepare($INSERT);
            $stmt->bind_param("issss",$rnum, $name, $email, $subject, $message);
            $stmt->execute();
            echo "OK";
       
        $stmt->close();
        $conn->close();
    }
} else {
    echo "All field are required";
    die();
}

?>
