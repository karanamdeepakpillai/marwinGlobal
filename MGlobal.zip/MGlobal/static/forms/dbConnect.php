<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "mglobal";
?>